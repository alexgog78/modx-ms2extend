<?php

$prefix = 'ms2extend_';

$_lang['ms2extend'] = 'ms2Extend';
$_lang[$prefix . 'desc'] = 'Extending miniShop2';

$_lang[$prefix . 'fields'] = 'Custom miniShop2 fields';
$_lang[$prefix . 'fields_desc'] = 'Creating custom fields for miniShop2 objects';
$_lang[$prefix . 'tabs'] = 'Additional tabs for miniShop2';
$_lang[$prefix . 'tabs_desc'] = 'Creating additional tabs for miniShop2 product, category and settings';
$_lang[$prefix . 'additional_properties'] = 'Additional properties';
$_lang[$prefix . 'undefined'] = '<span class="icon icon-lock" style="font-size: 200%;"></span><br />First, save the object';
$_lang[$prefix . 'indevelopment'] = '<span class="icon icon-cog" style="font-size: 200%;"></span><br />Section is under construction';

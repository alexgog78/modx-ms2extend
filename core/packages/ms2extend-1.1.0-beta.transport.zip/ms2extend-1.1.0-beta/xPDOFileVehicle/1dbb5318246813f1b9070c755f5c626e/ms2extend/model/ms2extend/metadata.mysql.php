<?php

$xpdo_meta_map = [
    'ms2extendTab' => [
        0 => 'ms2extendProductTab',
        1 => 'ms2extendCategoryTab',
        2 => 'ms2extendSettingsTab',
    ],
];

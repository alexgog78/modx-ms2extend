<?php

$prefix = 'ms2extend_field_';

$_lang[$prefix . 'list'] = 'Дополнительные поля miniShop2';
$_lang[$prefix . 'list_management'] = 'Создание дополнительных полей объектов miniShop2';

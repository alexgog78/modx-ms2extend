<?php

$prefix = 'ms2extend_';

$_lang['ms2extend'] = 'ms2Extend';
$_lang[$prefix . 'desc'] = 'Расширение miniShop2';

$_lang[$prefix . 'fields'] = 'Дополнительные поля miniShop2';
$_lang[$prefix . 'fields_desc'] = 'Создание дополнительных полей объектов miniShop2';
$_lang[$prefix . 'tabs'] = 'Дополнительные вкладки miniShop2';
$_lang[$prefix . 'tabs_desc'] = 'Создание дополнительных вкладок в карточке товарана, категории и настройках miniShop2';
$_lang[$prefix . 'additional_properties'] = 'Дополнительные свойства';
$_lang[$prefix . 'undefined'] = '<span class="icon icon-lock" style="font-size: 200%;"></span><br />Для начала сохраните объект';
$_lang[$prefix . 'indevelopment'] = '<span class="icon icon-cog" style="font-size: 200%;"></span><br />Раздел находится в разработке';

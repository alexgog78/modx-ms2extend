<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Extend.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Extend
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Extend
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'miniShop2' => '>=2.4.0',
      'abstractModule' => '>=1.1.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5e0cb06344222621c6b2f45f4ed6f519',
      'native_key' => 'ms2extend',
      'filename' => 'modNamespace/008d47dfbd8d1e9d0a6fc685aa948e7e.vehicle',
      'namespace' => 'ms2extend',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b26af5649291014f3785e9735aaab6cd',
      'native_key' => 'b26af5649291014f3785e9735aaab6cd',
      'filename' => 'xPDOFileVehicle/1dbb5318246813f1b9070c755f5c626e.vehicle',
      'namespace' => 'ms2extend',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4b1ef026487445ce9261942401d021be',
      'native_key' => '4b1ef026487445ce9261942401d021be',
      'filename' => 'xPDOFileVehicle/a9785c893fea62de3ccbe84a28c56fa6.vehicle',
      'namespace' => 'ms2extend',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '92092adb88919bd8dd48d59b38a706b7',
      'native_key' => 'ms2extend',
      'filename' => 'modMenu/e968fafed2adacd42b659e8f616dce45.vehicle',
      'namespace' => 'ms2extend',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7c3add897188c5d3d5b63b79b2870e32',
      'native_key' => 'ms2extend_fields',
      'filename' => 'modMenu/41263823775ecca592434b731992c112.vehicle',
      'namespace' => 'ms2extend',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8858e7731862aadcabd90da42777655b',
      'native_key' => 'ms2extend_tabs',
      'filename' => 'modMenu/791b963bd669b45e059d308da95a9673.vehicle',
      'namespace' => 'ms2extend',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '9c0e4a9228ef82a50e9803f154a07db4',
      'native_key' => 0,
      'filename' => 'modPlugin/99508c1a44a03cda56891089aea99679.vehicle',
      'namespace' => 'ms2extend',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47c8add670de31a7438dffa37444833d',
      'native_key' => 'ms2extendOnGetProductLayout',
      'filename' => 'modEvent/b417115d19fb6dc7dc63b909da0d5c9b.vehicle',
      'namespace' => 'ms2extend',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '391389156ce482c68bbfeb7ffe56b82a',
      'native_key' => 'ms2extendOnGetProductTabs',
      'filename' => 'modEvent/83bd6d15ab0ac4154277ad02828110b3.vehicle',
      'namespace' => 'ms2extend',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0bd6a4a5445f9611bcb0b080442683d7',
      'native_key' => 'ms2extendOnGetCategoryLayout',
      'filename' => 'modEvent/bec7aaf0de525b5520e40e14ce4bbb8a.vehicle',
      'namespace' => 'ms2extend',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ecb0dbc9ae511f92995d817885519cd6',
      'native_key' => 'ms2extendOnGetCategoryTabs',
      'filename' => 'modEvent/18c129ee3d69106f87b1773c6fe6cc04.vehicle',
      'namespace' => 'ms2extend',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fc8d9729967c772a10d11444bca7b30',
      'native_key' => 'ms2extendOnGetSettingsLayout',
      'filename' => 'modEvent/7069014a15a4eee47846bf62853bc3d8.vehicle',
      'namespace' => 'ms2extend',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc5b6e0efd76492ce7474c2ec9659c0f',
      'native_key' => 'ms2extendOnGetSettingsTabs',
      'filename' => 'modEvent/08497acb2e326dfc7c34823192713cf4.vehicle',
      'namespace' => 'ms2extend',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'cdd910548451957ec2da4abe38bba3cb',
      'native_key' => 1,
      'filename' => 'modCategory/029956115f5271265079ee7c205ac15a.vehicle',
      'namespace' => 'ms2extend',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'c6de6b5411ceb9e54c992ab4b30c5bff',
      'native_key' => 'c6de6b5411ceb9e54c992ab4b30c5bff',
      'filename' => 'xPDOScriptVehicle/89ee28988aefc6d4be8c40a4b2529b0e.vehicle',
      'namespace' => 'ms2extend',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '46342eb18bf26b7404dfc0c97ba9b763',
      'native_key' => '46342eb18bf26b7404dfc0c97ba9b763',
      'filename' => 'xPDOScriptVehicle/f2e90a507235d454569c055e3d6bc98e.vehicle',
      'namespace' => 'ms2extend',
    ),
  ),
);
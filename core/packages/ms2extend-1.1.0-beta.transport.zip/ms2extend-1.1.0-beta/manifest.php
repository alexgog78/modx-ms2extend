<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Extend.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Extend
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Extend
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'miniShop2' => '>=2.4.0',
      'abstractModule' => '>=1.1.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '50aac6140972cff89f86224f38cb2d74',
      'native_key' => 'ms2extend',
      'filename' => 'modNamespace/e2a4d56e9e35ab5f7577861713293ec8.vehicle',
      'namespace' => 'ms2extend',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '690c3176599e811a6e81ab94d8ca4431',
      'native_key' => '690c3176599e811a6e81ab94d8ca4431',
      'filename' => 'xPDOFileVehicle/b00cbf253d5c686db326ff46b778f773.vehicle',
      'namespace' => 'ms2extend',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9def18e7cbe237f34e9d892a074cf6dc',
      'native_key' => '9def18e7cbe237f34e9d892a074cf6dc',
      'filename' => 'xPDOFileVehicle/4e7f5f0e72595ec64ebc16cfac10edbf.vehicle',
      'namespace' => 'ms2extend',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6804c757baf950620092e45ffe4de9f1',
      'native_key' => 'ms2extend',
      'filename' => 'modMenu/9f0610862be7ccfa2b15186ab17e8afe.vehicle',
      'namespace' => 'ms2extend',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1609d73a0cc7a95d37fadde2d9aa3473',
      'native_key' => 'ms2extend_fields',
      'filename' => 'modMenu/183f0ba8e251402359bfffa992de52c0.vehicle',
      'namespace' => 'ms2extend',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fea2f2abfd06e6fb3c69c0b37bbce5dd',
      'native_key' => 'ms2extend_tabs',
      'filename' => 'modMenu/c5fb9304bfe37eaefa289549bd8071cc.vehicle',
      'namespace' => 'ms2extend',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '0f2bfd7cfb80a13ad74417779863cdc9',
      'native_key' => 0,
      'filename' => 'modPlugin/9fc029d93b5e7789446dbd459592039b.vehicle',
      'namespace' => 'ms2extend',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '395d1cddbda57378cb1156aeb81aef9d',
      'native_key' => 'ms2extendOnGetProductLayout',
      'filename' => 'modEvent/44df318c2f912029dc92a1f9e4c4c55f.vehicle',
      'namespace' => 'ms2extend',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5cb6606a19195036dda517fec5f5caf4',
      'native_key' => 'ms2extendOnGetProductTabs',
      'filename' => 'modEvent/76855c9aef01a6a1ea9e69808ab9b73a.vehicle',
      'namespace' => 'ms2extend',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9a6b374f752a654be6843f874a87d00',
      'native_key' => 'ms2extendOnGetCategoryLayout',
      'filename' => 'modEvent/07ea868cf758710f360e9f95af96b866.vehicle',
      'namespace' => 'ms2extend',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21333bc8dd60011cecc28ff4349b2452',
      'native_key' => 'ms2extendOnGetCategoryTabs',
      'filename' => 'modEvent/aa08bbc128bfb9450591e88d2a3486cb.vehicle',
      'namespace' => 'ms2extend',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dac6a8c34b7691bd195aa00ec8cdc81d',
      'native_key' => 'ms2extendOnGetSettingsLayout',
      'filename' => 'modEvent/e26f9988962cb6bf8213ef8c43f61596.vehicle',
      'namespace' => 'ms2extend',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44da5c44681c86dba02b729ea0efc4fc',
      'native_key' => 'ms2extendOnGetSettingsTabs',
      'filename' => 'modEvent/6713fc09c304e1a00af67730b7fc4de4.vehicle',
      'namespace' => 'ms2extend',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e14194f3ce1a525ec201bc078bd11ddd',
      'native_key' => 1,
      'filename' => 'modCategory/48ee6fe1ca735e08851054eb4b9c831a.vehicle',
      'namespace' => 'ms2extend',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'ea7a9ca21287cd6aaf8f6c08b69c882c',
      'native_key' => 'ea7a9ca21287cd6aaf8f6c08b69c882c',
      'filename' => 'xPDOScriptVehicle/7877405781bc6e065c4ccba0faf8670e.vehicle',
      'namespace' => 'ms2extend',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'c93a351ad7edba79a4e043f5ae171223',
      'native_key' => 'c93a351ad7edba79a4e043f5ae171223',
      'filename' => 'xPDOScriptVehicle/8bfd69733bf5b3a27fc0452b882e158a.vehicle',
      'namespace' => 'ms2extend',
    ),
  ),
);
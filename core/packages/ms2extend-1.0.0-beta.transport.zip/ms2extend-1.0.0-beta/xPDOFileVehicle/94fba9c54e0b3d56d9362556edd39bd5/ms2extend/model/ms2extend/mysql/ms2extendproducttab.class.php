<?php

require_once(dirname(__DIR__) . '/ms2extendproducttab.class.php');

class ms2extendProductTab_mysql extends ms2extendProductTab
{
}

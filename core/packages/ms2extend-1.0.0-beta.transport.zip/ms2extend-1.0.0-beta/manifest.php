<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Extend.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Extend
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Extend
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ff3987323c167ec64b2cbe9f91fde4d1',
      'native_key' => 'ms2extend',
      'filename' => 'modNamespace/e5a8c2a7afafae8dba75c1538434dca6.vehicle',
      'namespace' => 'ms2extend',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '370aba04ec0cf1fd7cf63a9b2b952e6e',
      'native_key' => '370aba04ec0cf1fd7cf63a9b2b952e6e',
      'filename' => 'xPDOFileVehicle/94fba9c54e0b3d56d9362556edd39bd5.vehicle',
      'namespace' => 'ms2extend',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '22498173d1b2339d681c542a674263c4',
      'native_key' => '22498173d1b2339d681c542a674263c4',
      'filename' => 'xPDOFileVehicle/8cde8142ceb4ce115963eda0209b8726.vehicle',
      'namespace' => 'ms2extend',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3f6741e88e9fb4d1945d9740f68f991',
      'native_key' => 'ms2extOnGetCategoryLayout',
      'filename' => 'modEvent/950a9d296188769c05e4d971d3bb4cd3.vehicle',
      'namespace' => 'ms2extend',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f404f7894287dc03dd1f449d2231d682',
      'native_key' => 'ms2extOnGetCategoryTabs',
      'filename' => 'modEvent/e39649dc3f4b92d1cfbe998f7856c913.vehicle',
      'namespace' => 'ms2extend',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef7070d3cbb37c7b1ea4d6f80bdaf8db',
      'native_key' => 'ms2extOnGetProductLayout',
      'filename' => 'modEvent/23846eb368742cd6c7b5a628490e88b5.vehicle',
      'namespace' => 'ms2extend',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f56cf97db3be928613c245e8d785931',
      'native_key' => 'ms2extOnGetProductTabs',
      'filename' => 'modEvent/c9ba9c2dca5f550375ee499341333838.vehicle',
      'namespace' => 'ms2extend',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '624f1e77a9665b8eaaffdee5d6b7d59a',
      'native_key' => 'ms2extOnGetSettingsLayout',
      'filename' => 'modEvent/27de3ee59babfacfcef720eb13fd1420.vehicle',
      'namespace' => 'ms2extend',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf252bcf2f4fc1e800342d87faf29751',
      'native_key' => 'ms2extOnGetSettingsTabs',
      'filename' => 'modEvent/cc36ab9fd09b288662fa8d68ed4a1f10.vehicle',
      'namespace' => 'ms2extend',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '889a054496fb2ffd4e9f4689d689bce2',
      'native_key' => 'ms2extend',
      'filename' => 'modMenu/9cfbb6fe9bffaa9262c4d4e69cbc06be.vehicle',
      'namespace' => 'ms2extend',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7a0bbe86983043726de7855f231841a7',
      'native_key' => 'ms2extend.section.fields',
      'filename' => 'modMenu/28daddb24eaf44515ed125113dc2df78.vehicle',
      'namespace' => 'ms2extend',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0a4b62ca8b7c30eecacd10e8a002e3dd',
      'native_key' => 'ms2extend.section.tabs',
      'filename' => 'modMenu/c8fd146022362d7824e838b1cdc37182.vehicle',
      'namespace' => 'ms2extend',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c145d265a19ae2a986f465e80662d657',
      'native_key' => 1,
      'filename' => 'modCategory/d7d4e610e0b837f51e799963855ba545.vehicle',
      'namespace' => 'ms2extend',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '47d92a45d122a147c9412b12e48be626',
      'native_key' => '47d92a45d122a147c9412b12e48be626',
      'filename' => 'xPDOScriptVehicle/a6aa7c41fed152f90afbd070ef8b8615.vehicle',
      'namespace' => 'ms2extend',
    ),
  ),
);
<?php

require_once(dirname(__DIR__) . '/ms2extendcategorytab.class.php');

class ms2extendCategoryTab_mysql extends ms2extendCategoryTab
{
}

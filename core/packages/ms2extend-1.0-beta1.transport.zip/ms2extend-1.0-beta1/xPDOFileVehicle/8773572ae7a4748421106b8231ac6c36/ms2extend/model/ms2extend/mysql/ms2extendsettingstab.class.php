<?php

require_once(dirname(__DIR__) . '/ms2extendsettingstab.class.php');

class ms2extendSettingsTab_mysql extends ms2extendSettingsTab
{
}

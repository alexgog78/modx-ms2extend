$(window.miniShop2).ready(function () {

});
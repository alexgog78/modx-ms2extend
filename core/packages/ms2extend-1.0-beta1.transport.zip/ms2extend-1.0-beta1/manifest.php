<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Extend.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Extend
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Extend
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ec60ab82bddd0ca22dd40250cbc48760',
      'native_key' => 'ms2extend',
      'filename' => 'modNamespace/9a80a999844d369beaa9fbe3b076b31d.vehicle',
      'namespace' => 'ms2extend',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '263287ca3c301deb17eed4400278098d',
      'native_key' => '263287ca3c301deb17eed4400278098d',
      'filename' => 'xPDOFileVehicle/8773572ae7a4748421106b8231ac6c36.vehicle',
      'namespace' => 'ms2extend',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '22fbc482c949ff14591678d17c95cac2',
      'native_key' => '22fbc482c949ff14591678d17c95cac2',
      'filename' => 'xPDOFileVehicle/ca9afbe49f65929686f5ce0a0ee51a85.vehicle',
      'namespace' => 'ms2extend',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac18e286bbbfbd8969b0ea62503c6642',
      'native_key' => 'ms2extOnGetCategoryLayout',
      'filename' => 'modEvent/6769d78ed9d0678ec29b681a21553894.vehicle',
      'namespace' => 'ms2extend',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '263685ab24d59bd08090d920bdc208e0',
      'native_key' => 'ms2extOnGetCategoryTabs',
      'filename' => 'modEvent/3f09889411c0a3e4f3a1e6a03ab9fc8f.vehicle',
      'namespace' => 'ms2extend',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31486ce05374de604e438418b7730072',
      'native_key' => 'ms2extOnGetProductLayout',
      'filename' => 'modEvent/1b7e1041e2eb6b93bfadaeed4409e8cd.vehicle',
      'namespace' => 'ms2extend',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f6a258673e5ba8a004a033a47491b7b',
      'native_key' => 'ms2extOnGetProductTabs',
      'filename' => 'modEvent/94c6128edb211d94df4e1ba38a9e9872.vehicle',
      'namespace' => 'ms2extend',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61e9303962f52ba0cf90e3283942280b',
      'native_key' => 'ms2extOnGetSettingsLayout',
      'filename' => 'modEvent/44d23dc9c5d60e2ab6370d3a0bf8fdfb.vehicle',
      'namespace' => 'ms2extend',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e13e98fda8db146bb3cd60eaeaa62e9',
      'native_key' => 'ms2extOnGetSettingsTabs',
      'filename' => 'modEvent/1a42d44cadbd9c4b3979244a68d0c9c5.vehicle',
      'namespace' => 'ms2extend',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '78ca8c6aba8002a73572f12dedb5521b',
      'native_key' => 'ms2extend',
      'filename' => 'modMenu/fef950cc6ef177b703de0d00352ec709.vehicle',
      'namespace' => 'ms2extend',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd9af3cce3d6bf6bc4781c6a584aac2a4',
      'native_key' => 'ms2extend.section.fields',
      'filename' => 'modMenu/1fe8a44348dbbb6dc53840a27b92f65e.vehicle',
      'namespace' => 'ms2extend',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '875642f35d6b8827fb76e48d2ac1a733',
      'native_key' => 'ms2extend.section.tabs',
      'filename' => 'modMenu/827d71145e2b6dd92cea82d2980fdb75.vehicle',
      'namespace' => 'ms2extend',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f95d35f049e428f5c0a271c6c513e274',
      'native_key' => 1,
      'filename' => 'modCategory/2583eda6255181192396ab4ec420daba.vehicle',
      'namespace' => 'ms2extend',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'a0106c059a19b14392bb8d7cd0bc373e',
      'native_key' => 'a0106c059a19b14392bb8d7cd0bc373e',
      'filename' => 'xPDOScriptVehicle/a00f0f5e7d6d3a17ca753e4317ecda72.vehicle',
      'namespace' => 'ms2extend',
    ),
  ),
);
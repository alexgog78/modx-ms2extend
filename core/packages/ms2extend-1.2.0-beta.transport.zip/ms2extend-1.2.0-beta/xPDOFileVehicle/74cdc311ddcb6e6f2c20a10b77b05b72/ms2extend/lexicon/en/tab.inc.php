<?php

$prefix = 'ms2extend_tab_';

$_lang[$prefix . 'list_product'] = 'Product tabs';
$_lang[$prefix . 'list_product_management'] = 'Manage your additional product tabs here. You can change them by double-clicking on the required field or by right-clicking on the required row.';
$_lang[$prefix . 'list_category'] = 'Category tabs';
$_lang[$prefix . 'list_category_management'] = 'Manage your additional category tabs here. You can change them by double-clicking on the required field or by right-clicking on the required row.';
$_lang[$prefix . 'list_settings'] = 'Settings tabs';
$_lang[$prefix . 'list_settings_management'] = 'Manage your additional settings tabs here. You can change them by double-clicking on the required field or by right-clicking on the required row.';
$_lang[$prefix . 'name'] = 'Name';
$_lang[$prefix . 'description'] = 'Description';
$_lang[$prefix . 'fields'] = 'fields';
$_lang[$prefix . 'xtypes'] = 'ExtJS';
$_lang[$prefix . 'sortorder'] = 'Sort order';
$_lang[$prefix . 'active'] = 'Active';

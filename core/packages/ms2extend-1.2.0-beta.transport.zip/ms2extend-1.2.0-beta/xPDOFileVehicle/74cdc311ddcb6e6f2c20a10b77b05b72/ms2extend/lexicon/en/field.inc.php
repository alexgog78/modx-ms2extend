<?php

$prefix = 'ms2extend_field_';

$_lang[$prefix . 'list'] = 'Custom miniShop2 fields';
$_lang[$prefix . 'list_management'] = 'Creating custom fields for miniShop2 objects';

'use strict';

Ext.apply(ms2Extend.function, {});

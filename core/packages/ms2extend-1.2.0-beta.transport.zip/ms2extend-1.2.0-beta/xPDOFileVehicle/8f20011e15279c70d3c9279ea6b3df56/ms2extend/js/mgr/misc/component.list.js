'use strict';

Ext.apply(ms2Extend.component, {});

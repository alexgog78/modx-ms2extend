<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Extend.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Extend
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Extend
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
      'miniShop2' => '>=2.4.0',
      'abstractModule' => '>=1.1.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6ffcb330ce9239810c8c86e0b9519f04',
      'native_key' => 'ms2extend',
      'filename' => 'modNamespace/c032e1cae299c5828df590382d002f18.vehicle',
      'namespace' => 'ms2extend',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '5654033fafc9907fb5a129998675ac0f',
      'native_key' => '5654033fafc9907fb5a129998675ac0f',
      'filename' => 'xPDOFileVehicle/74cdc311ddcb6e6f2c20a10b77b05b72.vehicle',
      'namespace' => 'ms2extend',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '89f560cd010070e14428a53030f50a9e',
      'native_key' => '89f560cd010070e14428a53030f50a9e',
      'filename' => 'xPDOFileVehicle/8f20011e15279c70d3c9279ea6b3df56.vehicle',
      'namespace' => 'ms2extend',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '37c4b97b6289bea37d76d93a259d7bb0',
      'native_key' => 0,
      'filename' => 'modPlugin/969d0f41177734cf57861805c075dcfe.vehicle',
      'namespace' => 'ms2extend',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '155986b3300cac8063f685202f48892e',
      'native_key' => 'ms2extendOnGetCategoryTabs',
      'filename' => 'modEvent/1bcce4b3a8aa19ce68f80bf2355f4ac7.vehicle',
      'namespace' => 'ms2extend',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9d98a7d0e2835ed9f840770c9a1583d',
      'native_key' => 'ms2extendOnGetProductTabs',
      'filename' => 'modEvent/9950f3752f15e5e0658c544df83f2822.vehicle',
      'namespace' => 'ms2extend',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d2b2512dd5de15f5bfe9915d99037d0',
      'native_key' => 'ms2extendOnGetSettingsTabs',
      'filename' => 'modEvent/c3cc105dc6c9eb3231ea7be5648d583a.vehicle',
      'namespace' => 'ms2extend',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5085a892ef8c306e416a6bcaefa64a00',
      'native_key' => 'ms2extend',
      'filename' => 'modMenu/c8f7de796a812f188916f151e373c1dc.vehicle',
      'namespace' => 'ms2extend',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4f4e3668811cebd5a9d1b8709131244a',
      'native_key' => 'ms2extend_fields',
      'filename' => 'modMenu/d5ccb2b727c6d2249f5dc1f23f5fdcd3.vehicle',
      'namespace' => 'ms2extend',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '140da592e46505576c215dbad1885aca',
      'native_key' => 'ms2extend_tabs',
      'filename' => 'modMenu/24479e22324b1e14d6394bdb0aac55a2.vehicle',
      'namespace' => 'ms2extend',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd1ffbf2724bedffe73ffeed12ecfa77d',
      'native_key' => 1,
      'filename' => 'modCategory/3808e8d985bf242fcd4bc3ccef229a72.vehicle',
      'namespace' => 'ms2extend',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'd6238bc39b5b119918da1c30d20f5274',
      'native_key' => 'd6238bc39b5b119918da1c30d20f5274',
      'filename' => 'xPDOScriptVehicle/9d1f8f6d8f77f09cc4bd642791c734db.vehicle',
      'namespace' => 'ms2extend',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '56ff00b8992df4b08aaf0b32bba3b996',
      'native_key' => '56ff00b8992df4b08aaf0b32bba3b996',
      'filename' => 'xPDOScriptVehicle/d5a55f0c987b880a867325b4cc077996.vehicle',
      'namespace' => 'ms2extend',
    ),
  ),
);